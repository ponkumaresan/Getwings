// Define a new module for our app
var app = angular.module("instantSearch", ['ngMap' ]);
// Create the instant search filter

app
    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.
                when('/home', {templateUrl: 'list.html',   controller: InstantSearchController}).
                when('/detail/:index', {templateUrl: 'detail.html',   controller: DetailCtrl}).
                otherwise({redirectTo: '/home'});
}]);
// The controller


function InstantSearchController($scope,$http, $rootScope, $location){

	// The data model. These items would normally be requested via AJAX,
	// but are hardcoded here for simplicity. See the next example for
	// tips on using AJAX.
$http.get("http://54.175.194.45:8028/posts").then(function(response) {
       $scope.items = response.data;
	   $rootScope.items=  $scope.items;
	   
    });
	 $scope.showDetail = function(id) {
       $location.path(id);
    }   

}
function DetailCtrl($scope, $routeParams, $rootScope,$http) {
   
    var index= $scope.index = $routeParams.index;
	$http.get("http://54.175.194.45:8028/posts").then(function(response) {
       $scope.items = response.data;
	   $rootScope.items=  $scope.items;
	    $scope.item = $rootScope.items[index];
    });
	
   
}